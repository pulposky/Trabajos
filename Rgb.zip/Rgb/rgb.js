const content = document.querySelector('.contenedor')

const cuadrito = document.createElement('div')

cuadrito.style.width = '100px'
cuadrito.style.height = '100px'
cuadrito.style.background = 'rgb(0,0,0)'
cuadrito.style.margin = '20px'
cuadrito.style.borderRadius = '50%'

const r = document.createElement('input')
r.setAttribute('type', 'range')
r.setAttribute('min', '0')
r.setAttribute('max', '255')
r.setAttribute('value', '0')

const g = document.createElement('input')
g.setAttribute('type', 'range')
g.setAttribute('min', '0')
g.setAttribute('max', '255')
g.setAttribute('value', '0')

const b = document.createElement('input')
b.setAttribute('type', 'range')
b.setAttribute('min', '0')
b.setAttribute('max', '255')
b.setAttribute('value', '0')


const letra1 = document.createElement('h3')
letra1.textContent = 'R (red)'

const letra2 = document.createElement('h3')
letra2.textContent = 'G (green)'

const letra3 = document.createElement('h3')
letra3.textContent = 'B (blue)'


r.addEventListener('input', color)
g.addEventListener('input', color)
b.addEventListener('input', color)

const rValor = document.createElement('h4')
rValor.textContent = '0'
const gValor = document.createElement('h4')
gValor.textContent = '0'
const bValor = document.createElement('h4')
bValor.textContent = '0'


function color(){
    cuadrito.style.background = `rgb(${r.value},${g.value},${b.value})`
    rValor.textContent = r.value
    gValor.textContent = g.value
    bValor.textContent = b.value
}

content.appendChild(letra1)
content.appendChild(r)
content.appendChild(rValor)
content.appendChild(letra2)
content.appendChild(g)
content.appendChild(gValor)
content.appendChild(letra3)
content.appendChild(b)
content.appendChild(bValor)
content.appendChild(cuadrito)