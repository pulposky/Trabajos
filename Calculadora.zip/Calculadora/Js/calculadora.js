let resultado = document.getElementById("resultado")

let primerNumero = ""
let operador = ""
let segundoNumero = ""

document.getElementById("btn1").onclick = function() { ponerNumero("1") }
document.getElementById("btn2").onclick = function() { ponerNumero("2") }
document.querySelector(".btn3").onclick = function() { ponerNumero("3") }
document.querySelector(".btn4").onclick = function() { ponerNumero("4") }
document.querySelector(".btn5").onclick = function() { ponerNumero("5") }
document.querySelector(".btn6").onclick = function() { ponerNumero("6") }
document.querySelector(".btn7").onclick = function() { ponerNumero("7") }
document.querySelector(".btn8").onclick = function() { ponerNumero("8") }
document.querySelector(".btn9").onclick = function() { ponerNumero("9") }
document.querySelector(".btn0").onclick = function() { ponerNumero("0") }
document.querySelector(".btnp").onclick = function() { ponerNumero(".") }

document.querySelector(".suma").onclick = function() { ponerOperador("+") }
document.querySelector(".resta").onclick = function() { ponerOperador("-") }
document.querySelector(".multi").onclick = function() { ponerOperador("*") }
document.querySelector(".div").onclick = function() { ponerOperador("/") }

resultado.value = "0"

document.querySelector(".igual").onclick = calcular

document.querySelector(".formatear").onclick = limpiar

function ponerNumero(num) {
    if (operador === "") {
        primerNumero += num
        resultado.value = primerNumero
    } else {
        segundoNumero += num
        resultado.value = segundoNumero
    }
}

function ponerOperador(op) {
    if (primerNumero !== "" && operador === "") {
        operador = op
        resultado.value = ""
    }
}

function limpiar(){
    primerNumero = ""
    operador = ""
    segundoNumero = ""
    resultado.value = "0"
}

function calcular(){

    if (primerNumero === "" || operador === "" || segundoNumero === "") {
        resultado.value = "Error"
        return
    }
    let n1 = parseFloat(primerNumero)
    let n2 = parseFloat(segundoNumero)
    let res = 0

    if (operador === "+") res = n1 + n2
    if (operador === "-") res = n1 - n2
    if (operador === "*") res = n1 * n2
    if (operador === "/") {
        if (n2 === 0) {
            resultado.value = "Error"
            return
        }
        res = n1 / n2
    }

    resultado.value = res
    primerNumero = res
    segundoNumero = ""
    operador = ""
}
