// Selección del contenedor principal
const container = document.getElementById('contenedor')
container.setAttribute('class','contenedor1')

// Elementos de datos personales
const nombre = document.createElement('input')
nombre.setAttribute('class','cuadro')

const apellido = document.createElement('input')
apellido.setAttribute('class','cuadro')

const documento = document.createElement('input')
documento.setAttribute('class','cuadro')

const correo = document.createElement('input')
correo.setAttribute('class','cuadro')

const celular = document.createElement('input')
celular.setAttribute('class','cuadro')

// Campos de texto
const camposTexto = document.createElement('h5')
camposTexto.setAttribute('class','camposTexto')
camposTexto.textContent = 'Nombre y apellido'

const camposTexto3 = document.createElement('h5')
camposTexto3.setAttribute('class','camposTexto3')
camposTexto3.textContent = 'Documento'

const camposTexto4 = document.createElement('h5')
camposTexto4.setAttribute('class','camposTexto4')
camposTexto4.textContent = 'Datos de contacto'

// Botones

const boton = document.createElement('button')
boton.setAttribute('class','boton')
boton.textContent = 'Enviar'

// Styling de los elementos

camposTexto.style.color = 'white'
camposTexto3.style.color = 'white'
camposTexto4.style.color = 'white'


// Atributos de los elementos
nombre.setAttribute('placeholder','Nombre')
nombre.setAttribute('type','text')

apellido.setAttribute('placeholder','Apellido')
apellido.setAttribute('type','text')

documento.setAttribute('placeholder','Documento')
documento.setAttribute('type','number')

correo.setAttribute('placeholder','Correo')
correo.setAttribute('type','email')


celular.setAttribute('placeholder','Celular')
celular.setAttribute('type','number')

// Event listener para el botón
boton.addEventListener('click', enviarInfo)



// Añadir los elementos al contenedor
container.appendChild(camposTexto)
container.appendChild(nombre)
container.appendChild(apellido)
container.appendChild(camposTexto3)
container.appendChild(documento)
container.appendChild(camposTexto4)
container.appendChild(correo)
container.appendChild(celular)
container.appendChild(boton)





// Función para manejar el evento de clic en el botón

function enviarInfo() {
    const datos = {
        nombre: nombre.value,
        apellido: apellido.value,
        documento: documento.value,
        correo: correo.value,
        celular: celular.value
    }

    // Validacion campos

if (datos.nombre === '' || datos.apellido === '' || datos.documento === '' || datos.correo === '' || datos.celular === '') {
        alert('Por favor, complete todos los campos.')
        return
    }
    console.log('Datos enviados:', datos)
    alert('Datos enviados correctamente')

    nombre.value = ''
    apellido.value = ''
    documento.value = ''
    correo.value = ''
    celular.value = ''

}